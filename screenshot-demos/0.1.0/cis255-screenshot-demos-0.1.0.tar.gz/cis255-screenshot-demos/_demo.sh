#!/usr/bin/env bash
# Instructor screenshots only: no exercises, host commands, sudo or containers.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
STATE_DIR="$ROOT/.demo-state"
die() { echo "DEMO ERROR: $*" >&2; exit 2; }
[[ $(id -u) != 0 ]] || die 'Run as your ordinary user, without sudo.'

# Preflight every known path before reading, writing or clearing any state.
[[ ! -L "$STATE_DIR" ]] || die 'Refusing linked demo state directory.'
[[ ! -e "$STATE_DIR" || -d "$STATE_DIR" ]] || die 'Demo state path is not a directory.'
for name in native-tryit native-proveit container-tryit container-proveit identity; do
  file="$STATE_DIR/$name"
  [[ ! -L "$file" ]] || die "Refusing linked demo state: $name"
  [[ ! -e "$file" || -f "$file" ]] || die "Demo state is not a regular file: $name"
  # A hard link could otherwise allow a write outside the demonstration folder.
  [[ ! -f "$file" || $(stat -c %h -- "$file") == 1 ]] || die "Refusing hard-linked demo state: $name"
done
umask 077
mkdir -p -- "$STATE_DIR"

read_state() {
  if [[ -f "$STATE_DIR/$1" ]]; then cat -- "$STATE_DIR/$1"; else echo not-started; fi
}
write_state() { printf '%s\n' "$2" > "$STATE_DIR/$1"; }
activity_state() {
  local state
  state="$(read_state "$1")"
  case "$state" in not-started|not-yet|pass) echo "$state" ;; *) die "Invalid state for $1; use demo-control.sh reset-all." ;; esac
}
valid_identity() { [[ $1 =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,23}$ ]]; }
notice() { echo 'SCREENSHOT DEMO ONLY: fictional activity; no real lab work is performed.'; }

feedback() {
  local state
  state="$(activity_state "$1")" || return $?
  case "$state" in
    not-started) echo 'NOT READY: Start the example activity first.'; return 2 ;;
    not-yet)
      echo 'NOT YET: One required task is incomplete.'
      echo 'HINT: Review the activity directions and check your work.'
      return 1 ;;
    pass)
      if [[ $1 == *proveit ]]; then
        echo 'PASS: Example assessment requirements satisfied.'
        echo 'Evidence is still required: follow the Blackboard submission directions.'
      else
        echo 'PASS: Example activity completed successfully.'
      fi ;;
  esac
}

native() {
  local kind="$1" action="$2" short="${1#native-}" state
  case "$action" in
    start)
      state="$(activity_state "$kind")" || return $?
      if [[ $state == not-started ]]; then
        write_state "$kind" not-yet
        echo "Ready: Example $short workspace prepared (simulated)."
        echo 'Workspace: fictional example files on the Rocky VM; no exercise files created.'
      else
        echo "Already started. Use example-$short-check.sh or example-$short-reset.sh."
      fi ;;
    check) feedback "$kind" ;;
    reset)
      write_state "$kind" not-started
      echo "Reset complete. Run example-$short-start.sh to try again." ;;
    *) die 'Unknown native demonstration command.' ;;
  esac
}

container_shell() {
  local activity="$1" identity="$2" cmd kind="container-${1#example-}"
  echo "Inside lc-${activity}-${identity} (simulated): run 'check' any time; 'exit' returns to Rocky."
  while true; do
    printf '[student@lc-%s-%s work]$ ' "$activity" "$identity"
    if ! IFS= read -r cmd; then printf '\n'; break; fi
    # Exact commands only; input is never evaluated or handed to a real shell.
    case "$cmd" in
      check) feedback "$kind" || true ;;
      exit|logout) echo 'exit'; break ;;
      pwd) echo '/home/student/work' ;;
      whoami) echo student ;;
      ls) echo 'instructions.txt  example-file.txt (simulated)' ;;
      help) echo 'Available demo commands: check, pwd, whoami, ls, help, exit' ;;
      '') ;;
      *) echo 'Screenshot demonstration only. No Linux commands are executed here.' ;;
    esac
  done
}

container() {
  local action="${1:-help}" activity="${2:-}" identity kind status
  case "$action" in
    help|--help|-h)
      [[ $# -le 1 ]] || die 'Usage: containers/lab help'
      cat <<'HELP'
containers/lab identify EXAMPLE_USERNAME
containers/lab list
containers/lab {start|enter|check|reset|status} {example-tryit|example-proveit}
Inside the simulated container: check, exit (or help).
HELP
      return ;;
    list)
      [[ $# == 1 ]] || die 'Usage: containers/lab list'
      printf 'example-tryit\nexample-proveit\n'; return ;;
    identify)
      [[ $# == 2 ]] && valid_identity "$activity" || die 'Usage: containers/lab identify USERNAME (1-24 letters/digits/_/-; begin with letter/digit).'
      identity="$(read_state identity)"
      if [[ -f "$STATE_DIR/identity" && $identity != "$activity" ]]; then
        die 'Identity already assigned. Use demo-control.sh reset-all before changing it.'
      fi
      write_state identity "$activity"
      echo "Student ID set: $activity"; return ;;
    start|enter|check|reset|status)
      [[ $# == 2 ]] || die "Usage: containers/lab $action ACTIVITY"
      [[ $activity == example-tryit || $activity == example-proveit ]] || die 'Unknown example activity (use containers/lab list).'
      [[ -f "$STATE_DIR/identity" ]] || die 'First run: containers/lab identify EXAMPLE_USERNAME'
      identity="$(read_state identity)"
      valid_identity "$identity" || die 'Invalid saved identity; use demo-control.sh reset-all.'
      kind="container-${activity#example-}"
      status="$(activity_state "$kind")" || return $? ;;
    *) die 'Unknown demo command. Use containers/lab help.' ;;
  esac
  case "$action" in
    start)
      if [[ $status == not-started ]]; then
        write_state "$kind" not-yet
        echo "Ready: $activity - $identity (simulated)"
      fi
      container_shell "$activity" "$identity" ;;
    enter)
      [[ $status != not-started ]] || die "Activity not started. Use: containers/lab start $activity"
      container_shell "$activity" "$identity" ;;
    check) feedback "$kind" ;;
    reset)
      # Container reset recreates immediately, unlike native reset-then-start.
      write_state "$kind" not-yet
      echo "Ready: $activity - $identity (simulated)"
      echo 'Reset complete. All previous work for this activity was discarded (simulated).' ;;
    status)
      if [[ $status == not-started ]]; then echo "Not started: $activity"
      else echo "Example activity $activity: running (simulated)"; fi ;;
  esac
}

control() {
  local kind="${1:-}" condition="${2:-}"
  if [[ $kind == reset-all && $# == 1 ]]; then
    for kind in native-tryit native-proveit container-tryit container-proveit identity; do
      rm -f -- "$STATE_DIR/$kind"
    done
    echo 'All screenshot demo states and identity cleared.'
    return
  fi
  [[ $# == 2 ]] || die 'Usage: demo-control.sh KIND {pass|not-yet|not-started}, or reset-all'
  case "$kind" in native-tryit|native-proveit|container-tryit|container-proveit) ;; *) die 'Choose native-tryit, native-proveit, container-tryit or container-proveit.' ;; esac
  case "$condition" in pass|not-yet|not-started) ;; *) die 'Choose pass, not-yet or not-started.' ;; esac
  write_state "$kind" "$condition"
  echo "Screenshot demo $kind set to $condition (no activity work performed)."
}

notice
case "${1:-}" in
  native-tryit|native-proveit)
    [[ $# == 2 ]] || die 'Invalid native demonstration invocation.'
    native "$1" "$2" ;;
  container) shift; container "$@" ;;
  control) shift; control "$@" ;;
  *) die 'Unknown screenshot demo type.' ;;
esac
