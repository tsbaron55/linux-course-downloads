#!/usr/bin/env bash
# SCREENSHOT DEMO ONLY: No real course activity is performed.
set -euo pipefail
D="$(cd -- "$(dirname -- "$0")" && pwd -P)"
exec bash "$D/../_demo.sh" native-proveit check
