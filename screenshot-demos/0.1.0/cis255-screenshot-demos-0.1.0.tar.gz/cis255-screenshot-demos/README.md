# Instructor screenshot demonstrations

Private documentation tools, **not student exercises or assessments**. Adapted
from the supplied `cis255-screenshot-demos.tar.gz` (SHA-256
`e289a62a85ed6d4e798f87f2436996bfc7cd5412f15b70e216b1ed9279d155c4`).
These scripts simulate feedback and a container prompt; they never perform an
exercise, run Podman, use sudo, access protected reports, or submit to Blackboard.
The only changing files are five small files under this folder's `.demo-state/`.

Requires Bash and ordinary Linux utilities, including GNU `stat` (Rocky 10.2).
Run as an ordinary user in a separate copy of this folder, for example
`~/cis255-screenshot-demos`. Keep it outside both real lab installation roots.
No installation, PATH change, shell alias, or packages are needed. From the private
checkout, copy with:

```bash
cp -R instructor/screenshot-demos "$HOME/cis255-screenshot-demos"
cd "$HOME/cis255-screenshot-demos"
```

Use a fresh destination for that copy. Every invocation retains a visible
`SCREENSHOT DEMO ONLY` notice. Keep that notice in the image and caption it
**Fictional example output**; do not crop away the distinction.

## How these commands correspond to the Word guides

Reviewed the supplied `CIS255_M0_Introduction_to_Course_Lab_Activities_EXAMPLES`,
`CIS255_Using_Try_It_Activities_EXAMPLES`, and
`CIS255_Using_Prove_It_Activities_EXAMPLES` Word guides (October 16, 2026).
The fictional names below match those guides. No Word files are changed here.

| Guide example | Command to capture with this package |
| --- | --- |
| `bash example-tryit-start.sh` (and check/reset) | Same basename, after changing into this package's `native/` directory |
| `bash example-proveit-start.sh` (and check/reset) | Same basename, in this package's `native/` directory |
| `~/cis255-containers/lab ... example-tryit` | `./containers/lab ... example-tryit` from this package |
| `~/cis255-containers/lab ... example-proveit` | `./containers/lab ... example-proveit` from this package |
| Container `check` / `exit` | Same words at the **simulated** container prompt |

Never run these fictional activity IDs through the installed student `lab`, or
copy/alias this demo launcher over it. Container Prove It is a possible future
workflow, not a claim that a real assessment has been installed. Output follows
the real `Ready`, `NOT READY`, `NOT YET`, `PASS`, identity and reset conventions
where useful; it is not an exact transcript of production scripts.

## M0: identify the host terminal

Use a genuine Rocky terminal under the ordinary account. To provide an honest
host label, type:

```bash
printf 'Rocky Linux VM - host terminal (ordinary user)\n'
```

Capture the ordinary host prompt and that label. Do not substitute the simulated
container prompt or claim this command identifies the OS automatically.

## Native Try It screenshots

From the demo folder, clear prior screenshot state and enter `native/`:

```bash
bash demo-control.sh reset-all
cd native
bash example-tryit-check.sh      # NOT READY, exit 2
bash example-tryit-start.sh      # Ready + simulated workspace message
bash example-tryit-check.sh      # NOT YET + hint, exit 1
```

Run this instructor switch **between captures**, then capture the normal check:

```bash
bash ../demo-control.sh native-tryit pass
bash example-tryit-check.sh      # PASS, exit 0
bash example-tryit-start.sh      # Already started; PASS remains
bash example-tryit-reset.sh      # Clears only this example
bash example-tryit-check.sh      # NOT READY again
bash example-tryit-start.sh
bash example-tryit-check.sh      # NOT YET again
cd ..
```

## Native Prove It screenshots

From the demo folder:

```bash
cd native
bash example-proveit-check.sh    # NOT READY
bash example-proveit-start.sh    # Ready; no protected resources created
bash example-proveit-check.sh    # NOT YET
bash ../demo-control.sh native-proveit pass   # instructor switch
bash example-proveit-check.sh    # PASS + evidence/submission reminder
bash example-proveit-reset.sh
bash example-proveit-check.sh    # NOT READY
bash example-proveit-start.sh
bash example-proveit-check.sh    # NOT YET
cd ..
```

This demonstration never needs sudo. Real native assessment privileges and
required evidence depend on the actual assignment; a local PASS is not submission
or a grade. The demo does not create a recording or any assessment evidence.

## Container Try It screenshots

From the demo folder (use the fictional identity, not a student's account):

```bash
./containers/lab identify exampleuser
./containers/lab list
./containers/lab check example-tryit   # NOT READY
./containers/lab start example-tryit
```

At `[student@lc-example-tryit-exampleuser work]$`, type one command per line:

```text
check
pwd
exit
```

The incomplete `check` leaves the simulated shell open. After `exit`, the real
Rocky prompt returns. Switch progress between captures and reopen:

```bash
bash demo-control.sh container-tryit pass
./containers/lab start example-tryit
```

Inside, type `check` (PASS), then `exit`. From Rocky:

```bash
./containers/lab check example-tryit   # PASS persists after exit/reentry
./containers/lab reset example-tryit  # Discards simulated progress
./containers/lab check example-tryit  # NOT YET: already initialized
./containers/lab start example-tryit
```

Type `check`, then `exit` again to complete the fresh-workspace screenshot.

## Potential container Prove It screenshots

Use the same identified demo folder:

```bash
./containers/lab start example-proveit
```

Inside, type `check` (NOT YET) and `exit`. Then from Rocky:

```bash
bash demo-control.sh container-proveit pass
./containers/lab start example-proveit
```

Inside, type `check` (PASS + evidence reminder) and `exit`. From Rocky:

```bash
./containers/lab check example-proveit
./containers/lab reset example-proveit
./containers/lab check example-proveit  # NOT YET
```

Caption this explicitly as a **fictional future container assessment example**.

## Controls, repeatability and boundaries

`bash demo-control.sh KIND STATE` accepts `native-tryit`, `native-proveit`,
`container-tryit`, or `container-proveit`, and `pass`, `not-yet`, or `not-started`.
The latter produces NOT READY. Set any of these between captures; repeated checks
do not advance progress. Container commands require identification first.
`bash demo-control.sh reset-all` clears all four progress values and the identity.
Single-activity resets preserve the identity and other examples.

Exit codes: PASS is 0, NOT YET is 1, NOT READY and invalid invocations are 2.
Leaving the simulated shell returns 0 even after an unsuccessful check, as a
normal interactive session would. EOF also leaves the shell without clearing
progress. `start` reopens existing progress; `enter` only reopens an already
started example. `status` reports simulated status. Use `help` at the prompt for
the small command list. Other input is rejected, never evaluated by a real shell.
Whitespace, pipelines, redirections and arbitrary Linux commands are unsupported.
This is a screenshot aid, not a terminal emulator or a functional exercise.

State links and nonregular files are refused before mutation; reset does not
recursively delete anything. If someone replaces a state file with a link or
directory, remove only that unexpected entry manually in this private demo copy.
Concurrent screenshot sessions using one folder are unsupported; use a separate
copy per instructor. No display/username overrides or framework configuration.

## Smoke tests

```bash
bash tests/smoke.sh
```

The tests use a temporary copy **inside this demo folder**, remove that copy on
exit, and preserve your screenshot progress. They test all four workflows,
return codes, preservation, repeated resets, bad arguments, corrupt state and
linked-state refusal. No real labs, Podman, sudo, network or host changes occur.
See `VALIDATION.md` for the observed Rocky results and interactive prompt checks.
