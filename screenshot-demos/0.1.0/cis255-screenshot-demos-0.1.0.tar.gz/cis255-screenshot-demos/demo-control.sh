#!/usr/bin/env bash
# Instructor-only switch; run between screenshots, then capture the check.
set -euo pipefail
D="$(cd -- "$(dirname -- "$0")" && pwd -P)"
exec bash "$D/_demo.sh" control "$@"
