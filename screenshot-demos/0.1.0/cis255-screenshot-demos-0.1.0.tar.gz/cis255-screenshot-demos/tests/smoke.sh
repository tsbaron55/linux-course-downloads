#!/usr/bin/env bash
# Unprivileged, disposable tests. No course installation or container access.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "$0")/.." && pwd -P)"
[[ $(id -u) != 0 ]] || { echo 'Run tests as an ordinary user.' >&2; exit 2; }
TEMP="$(mktemp -d "$ROOT/.smoke.XXXXXXXX")"
trap 'rm -rf -- "$TEMP"' EXIT
D="$TEMP/demo copy"
mkdir -p "$D" "$TEMP/bin"
cp -- "$ROOT/_demo.sh" "$ROOT/demo-control.sh" "$D/"
cp -R -- "$ROOT/native" "$ROOT/containers" "$D/"
# If the demos unexpectedly try either command, fail and leave evidence in TEMP.
for command in podman sudo; do
  printf '#!/usr/bin/env bash\necho forbidden >> "%s"\nexit 99\n' "$TEMP/forbidden" > "$TEMP/bin/$command"
  chmod +x "$TEMP/bin/$command"
done
export PATH="$TEMP/bin:$PATH"
count=0
expect() {
  local expected="$1" text="$2" output rc=0
  shift 2
  output="$("$@" 2>&1)" || rc=$?
  if [[ $rc != "$expected" || $output != *"$text"* ]]; then
    printf 'FAIL: %s (wanted rc=%s, text=%s; got rc=%s)\n%s\n' "$*" "$expected" "$text" "$rc" "$output" >&2
    exit 1
  fi
  count=$((count + 1))
  printf 'PASS %s: %s [exit %s]\n' "$count" "$text" "$rc"
}
session() { printf '%s\n' "$1" | "$D/containers/lab" "${@:2}"; }

expect 0 'states and identity cleared' bash "$D/demo-control.sh" reset-all
for type in tryit proveit; do
  check="$D/native/example-$type-check.sh"
  start="$D/native/example-$type-start.sh"
  reset="$D/native/example-$type-reset.sh"
  expect 2 'NOT READY' bash "$check"
  expect 0 'Ready:' bash "$start"
  expect 1 'NOT YET' bash "$check"
  expect 1 'NOT YET' bash "$check"
  expect 0 'set to pass' bash "$D/demo-control.sh" "native-$type" pass
  expect 0 'PASS:' bash "$check"
  [[ $type != proveit ]] || expect 0 'Evidence is still required' bash "$check"
  expect 0 'Already started' bash "$start"
  expect 0 'PASS:' bash "$check"
  expect 0 'set to not-yet' bash "$D/demo-control.sh" "native-$type" not-yet
  expect 1 'NOT YET' bash "$check"
  for attempt in 1 2 3; do
    expect 0 'Reset complete' bash "$reset"
    expect 2 'NOT READY' bash "$check"
    expect 0 'Ready:' bash "$start"
    expect 1 'NOT YET' bash "$check"
  done
  expect 0 'set to not-started' bash "$D/demo-control.sh" "native-$type" not-started
  expect 2 'NOT READY' bash "$check"
  printf 'corrupt\n' > "$D/.demo-state/native-$type"
  expect 2 'Invalid state' bash "$check"
  expect 2 'Invalid state' bash "$start"
  expect 0 'Reset complete' bash "$reset"
done

expect 0 'example-proveit' "$D/containers/lab" list
expect 0 'identify' "$D/containers/lab" help
expect 2 'First run:' "$D/containers/lab" start example-tryit
expect 2 'Usage:' "$D/containers/lab" identify '../bad'
expect 0 'Student ID set: exampleuser' "$D/containers/lab" identify exampleuser
expect 0 'Student ID set: exampleuser' "$D/containers/lab" identify exampleuser
expect 2 'Identity already assigned' "$D/containers/lab" identify differentuser
for type in tryit proveit; do
  act="example-$type"
  expect 2 'NOT READY' "$D/containers/lab" check "$act"
  expect 2 'Activity not started' "$D/containers/lab" enter "$act"
  expect 0 'Not started' "$D/containers/lab" status "$act"
  expect 0 'NOT YET' session $'check\nexit' start "$act"
  expect 0 "[student@lc-$act-exampleuser work]$" session exit start "$act"
  expect 0 '/home/student/work' session $'pwd\nexit' enter "$act"
  expect 0 'instructions.txt' session $'ls\nwhoami\nhelp\nexit' start "$act"
  expect 0 'No Linux commands are executed' session "touch $D/pwned" start "$act"
  [[ ! -e "$D/pwned" ]] || { echo 'Input was executed!' >&2; exit 1; }
  expect 1 'NOT YET' "$D/containers/lab" check "$act"
  expect 0 'set to pass' bash "$D/demo-control.sh" "container-$type" pass
  expect 0 'PASS:' session $'check\nexit' start "$act"
  expect 0 'PASS:' session $'check\nlogout' enter "$act"
  expect 0 'PASS:' "$D/containers/lab" check "$act"
  [[ $type != proveit ]] || expect 0 'Evidence is still required' "$D/containers/lab" check "$act"
  # EOF also preserves progress and returns without hanging.
  expect 0 'Inside lc-' session '' start "$act"
  expect 0 'PASS:' "$D/containers/lab" check "$act"
  expect 0 'running (simulated)' "$D/containers/lab" status "$act"
  for attempt in 1 2 3; do
    expect 0 'Reset complete' "$D/containers/lab" reset "$act"
    expect 1 'NOT YET' "$D/containers/lab" check "$act"
    expect 0 'NOT YET' session $'check\nexit' start "$act"
  done
  expect 0 'set to not-started' bash "$D/demo-control.sh" "container-$type" not-started
  expect 2 'NOT READY' "$D/containers/lab" check "$act"
  printf 'corrupt\n' > "$D/.demo-state/container-$type"
  expect 2 'Invalid state' "$D/containers/lab" check "$act"
  expect 2 'Invalid state' "$D/containers/lab" start "$act"
  expect 2 'Invalid state' "$D/containers/lab" reset "$act"
  expect 0 'set to not-yet' bash "$D/demo-control.sh" "container-$type" not-yet
done

# Resets of one example leave other state and identity alone.
expect 0 'set to pass' bash "$D/demo-control.sh" container-proveit pass
expect 0 'set to pass' bash "$D/demo-control.sh" native-proveit pass
expect 0 'Reset complete' "$D/containers/lab" reset example-tryit
expect 0 'Reset complete' bash "$D/native/example-tryit-reset.sh"
expect 0 'PASS:' "$D/containers/lab" check example-proveit
expect 0 'PASS:' bash "$D/native/example-proveit-check.sh"
expect 0 'exampleuser' "$D/containers/lab" identify exampleuser
expect 2 'Usage:' "$D/containers/lab" reset example-tryit extra
expect 2 'Usage:' "$D/containers/lab" identify exampleuser extra
expect 2 'Usage:' "$D/containers/lab" list extra
expect 2 'Unknown example activity' "$D/containers/lab" check permissions
expect 2 'Unknown demo command' "$D/containers/lab" update
expect 2 'Usage:' bash "$D/demo-control.sh" native-tryit pass extra
expect 2 'Choose pass' bash "$D/demo-control.sh" native-tryit invalid
printf 'bad identity\n' > "$D/.demo-state/identity"
expect 2 'Invalid saved identity' "$D/containers/lab" start example-tryit
expect 0 'states and identity cleared' bash "$D/demo-control.sh" reset-all
# A valid identity literally named not-started must still be immutable.
expect 0 'Student ID set: not-started' "$D/containers/lab" identify not-started
expect 2 'Identity already assigned' "$D/containers/lab" identify differentuser

# Unrelated files within the test area must never change or be removed.
printf 'sentinel\n' > "$TEMP/sentinel"
printf 'keep\n' > "$D/.demo-state/unrelated"
ln -s "$TEMP/sentinel" "$D/.demo-state/native-tryit"
expect 2 'Refusing linked demo state' bash "$D/demo-control.sh" reset-all
expect 2 'Refusing linked demo state' bash "$D/native/example-tryit-start.sh"
[[ $(cat "$D/.demo-state/identity") == not-started ]]  # no partial clear
rm -- "$D/.demo-state/native-tryit"
ln "$TEMP/sentinel" "$D/.demo-state/identity-linked"
mv -- "$D/.demo-state/identity-linked" "$D/.demo-state/identity"
expect 2 'Refusing hard-linked demo state' "$D/containers/lab" identify exampleuser
rm -- "$D/.demo-state/identity"
mkdir "$D/.demo-state/native-tryit"
expect 2 'not a regular file' bash "$D/demo-control.sh" reset-all
rmdir "$D/.demo-state/native-tryit"
mv -- "$D/.demo-state" "$D/saved-state"
ln -s "$D/saved-state" "$D/.demo-state"
expect 2 'linked demo state directory' bash "$D/demo-control.sh" reset-all
rm -- "$D/.demo-state"
mv -- "$D/saved-state" "$D/.demo-state"
expect 0 'states and identity cleared' bash "$D/demo-control.sh" reset-all
expect 2 'NOT READY' bash "$D/native/example-proveit-check.sh"
expect 2 'First run:' "$D/containers/lab" check example-proveit
[[ $(cat "$TEMP/sentinel") == sentinel && $(cat "$D/.demo-state/unrelated") == keep ]]
[[ ! -e "$TEMP/forbidden" ]]
[[ $(find "$D/.demo-state" -maxdepth 1 -type f | wc -l) == 1 ]]
echo "PASS: $count command/output/exit-code checks; isolation and no sudo/Podman calls verified."
