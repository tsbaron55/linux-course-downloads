#!/usr/bin/env bash
set -euo pipefail
D="$(cd -- "$(dirname -- "$0")" && pwd -P)"
WORK="$D/work"
[[ ! -L "$WORK" ]] || { echo 'ERROR: Unsafe workspace link.' >&2; exit 2; }
[[ ! -e "$WORK" || -d "$WORK" ]] || { echo 'ERROR: Workspace is not a directory.' >&2; exit 2; }
rm -rf -- "$WORK"     # Only this activity's user-owned work folder.
echo 'Reset complete. Run m2-tryit-start.sh to try again.'
