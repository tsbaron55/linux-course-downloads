#!/usr/bin/env bash
set -euo pipefail
D="$(cd -- "$(dirname -- "$0")" && pwd -P)"
WORK="$D/work"

for folder in "$WORK" "$WORK/inbox" "$WORK/acknowledgments"; do
    [[ -d "$folder" && ! -L "$folder" ]] || { echo 'NOT READY: Run m2-tryit-start.sh first.'; exit 2; }
done
for ticket in ticket-101.txt ticket-102.txt .ticket-103.txt; do
    [[ -f "$WORK/inbox/$ticket" && ! -L "$WORK/inbox/$ticket" ]] &&
        cmp -s -- "$D/seed/inbox/$ticket" "$WORK/inbox/$ticket" || {
        echo 'NOT YET: Restore the original tickets with m2-tryit-reset.sh.'; exit 1;
    }
done
shopt -s nullglob dotglob
acks=("$WORK/acknowledgments/"*)
if (( ${#acks[@]} == 1 )) && [[ "${acks[0]}" == "$WORK/acknowledgments/ticket-103.ok" && -f "${acks[0]}" && ! -L "${acks[0]}" ]]; then
    echo 'PASS: Hidden ticket acknowledged; original tickets are intact.'
else
    echo 'NOT YET: Create one acknowledgment for the hidden ticket.'
    echo 'HINT: Check the ls options for showing names beginning with a dot.'
    exit 1
fi
