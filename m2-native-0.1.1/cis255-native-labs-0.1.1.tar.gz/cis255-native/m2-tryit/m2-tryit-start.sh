#!/usr/bin/env bash
set -euo pipefail
D="$(cd -- "$(dirname -- "$0")" && pwd -P)"
WORK="$D/work"

if [[ -L "$WORK" ]]; then echo 'ERROR: Unsafe workspace link.' >&2; exit 2; fi
if [[ -e "$WORK" ]]; then
    [[ -d "$WORK" ]] || { echo 'ERROR: Workspace is not a directory.' >&2; exit 2; }
    echo 'Already started. Use m2-tryit-check.sh or m2-tryit-reset.sh.'
    exit 0
fi
mkdir -p -- "$WORK/inbox" "$WORK/acknowledgments"
cp -- "$D/seed/inbox/"* "$WORK/inbox/"
cp -- "$D/seed/inbox/.ticket-103.txt" "$WORK/inbox/"
echo "Ready: $WORK/inbox"
