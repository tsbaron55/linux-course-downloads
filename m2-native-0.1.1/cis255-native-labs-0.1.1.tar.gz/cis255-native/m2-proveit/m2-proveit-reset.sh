#!/usr/bin/env bash
source "$(cd -- "$(dirname -- "$0")" && pwd -P)/_common.sh"
rootdir "$BASE"
rootdir "$PRIVATE"
rootdir "$REPORTS"

# Only remove the three known reports. Refuse unexpected files or links.
shopt -s nullglob dotglob
reports=("$REPORTS/"*)
[[ ${#reports[@]} == 3 ]] || fail 'Unexpected report contents. Nothing deleted. Contact your instructor.'
for n in report-218.log report-219.log report-220.log; do
    [[ -f "$REPORTS/$n" && ! -L "$REPORTS/$n" && $(stat -c %u "$REPORTS/$n") == 0 && $(stat -c %a "$REPORTS/$n") == 600 ]] || fail 'Unsafe or unprotected report. Nothing deleted.'
done
private_items=("$PRIVATE/"*)
if (( ${#private_items[@]} != 1 )) || [[ "${private_items[0]}" != "$REPORTS" ]]; then
    fail 'Unexpected protected files. Nothing deleted. Contact your instructor.'
fi

acks=("$ACK/"*)
for f in "${acks[@]}"; do
    [[ -f "$f" && ! -L "$f" && "$f" == "$ACK"/report-*.ok ]] || fail 'Unexpected acknowledgment. Nothing deleted.'
done

rm -- "$REPORTS/report-218.log" "$REPORTS/report-219.log" "$REPORTS/report-220.log"
rmdir -- "$REPORTS" "$PRIVATE"
# Only remove the activity acknowledgment files (the folder itself stays).
if (( ${#acks[@]} )); then rm -- "${acks[@]}"; fi
echo 'Reset complete. Run m2-proveit-start.sh to try again.'
