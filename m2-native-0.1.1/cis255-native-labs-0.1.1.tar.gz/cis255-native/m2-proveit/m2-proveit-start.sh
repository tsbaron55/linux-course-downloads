#!/usr/bin/env bash
source "$(cd -- "$(dirname -- "$0")" && pwd -P)/_common.sh"

if [[ -e "$BASE" || -L "$BASE" ]]; then rootdir "$BASE"; else install -d -m 700 "$BASE"; fi
if [[ -e "$PRIVATE" || -L "$PRIVATE" ]]; then
    rootdir "$PRIVATE"
    [[ ! -e "$PRIVATE/.cis255-m2-v1" ]] || fail 'Previous v1 test state found; ask instructor before switching versions.'
    rootdir "$REPORTS"
    echo 'Already started. Use m2-proveit-check.sh or m2-proveit-reset.sh.'
    exit 0
fi
install -d -m 700 "$PRIVATE" "$REPORTS"

# The username determines which of three reports is newest.
value=$(printf '%s' "$SUDO_USER" | cksum)
newest=$(( ${value%% *} % 3 ))
reports=(report-218.log report-219.log report-220.log)
for i in 0 1 2; do
    file="$REPORTS/${reports[i]}"
    printf 'CIS255 maintenance report %s\nStatus: Awaiting review\n' "${reports[i]}" > "$file"
    chmod 600 "$file"
    # Distinct October 2026 calendar dates, visible even in a narrow ls listing.
    stamp=$(( 1790856000 + (i == newest ? 4 : i) * 86400 ))
    touch -d "@$stamp" "$file"
done
echo "Ready. Protected reports: $REPORTS"
echo "Acknowledgments: $ACK"
