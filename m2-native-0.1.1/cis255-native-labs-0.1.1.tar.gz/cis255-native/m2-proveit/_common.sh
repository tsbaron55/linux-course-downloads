#!/usr/bin/env bash
# Shared paths and basic safety checks for the privileged activity.
set -euo pipefail
fail() { echo "ERROR: $*" >&2; exit 2; }
[[ $(id -u) == 0 && ${SUDO_UID:-} =~ ^[1-9][0-9]*$ && -n ${SUDO_USER:-} ]] || fail 'Run from your regular account using sudo bash.'
D="$(cd -- "$(dirname -- "${BASH_SOURCE[1]}")" && pwd -P)"
STUDENT_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
[[ "$D" == "$STUDENT_HOME/cis255-native/m2-proveit" ]] || fail 'Install the package under ~/cis255-native/m2-proveit.'
BASE=/var/lib/cis255-m2-proveit
PRIVATE="$BASE/uid-$SUDO_UID"
REPORTS="$PRIVATE/reports"
ACK="$D/reviewed"
[[ -d "$ACK" && ! -L "$ACK" ]] || fail 'Student reviewed folder missing or unsafe.'
rootdir() {
    [[ -d "$1" && ! -L "$1" && $(stat -c %u "$1") == 0 && $(stat -c %a "$1") == 700 ]] || fail "Unsafe or missing course directory: $1"
}
