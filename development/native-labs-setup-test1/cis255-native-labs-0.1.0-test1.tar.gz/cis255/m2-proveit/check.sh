#!/usr/bin/env bash
source "$(cd -- "$(dirname -- "$0")" && pwd -P)/_common.sh"
rootdir "$BASE"
rootdir "$PRIVATE"
rootdir "$REPORTS"

# Verify the three original reports, including their timestamps.
value=$(printf '%s' "$SUDO_USER" | cksum)
newest=$(( ${value%% *} % 3 ))
reports=(report-218.log report-219.log report-220.log)
shopt -s nullglob dotglob
entries=("$REPORTS/"*)
[[ ${#entries[@]} == 3 ]] || fail 'Unexpected report files; reset the activity.'
for i in 0 1 2; do
    file="$REPORTS/${reports[i]}"
    [[ -f "$file" && ! -L "$file" && $(stat -c %u "$file") == 0 && $(stat -c %a "$file") == 600 ]] || fail 'A report is missing or is not root-owned and protected (0600).'
    expected="$(printf 'CIS255 maintenance report %s\nStatus: Awaiting review' "${reports[i]}")"
    [[ $(cat "$file") == "$expected" ]] || fail 'A report was modified; reset the activity.'
    stamp=$(( 1790856000 + (i == newest ? 4 : i) * 86400 ))
    [[ $(stat -c %Y "$file") == "$stamp" ]] || fail 'A report timestamp changed; reset the activity.'
done

acks=("$ACK/"*)
expected_ack="$ACK/${reports[newest]%.log}.ok"
if (( ${#acks[@]} == 1 )) && [[ "${acks[0]}" == "$expected_ack" && -f "${acks[0]}" && ! -L "${acks[0]}" ]]; then
    echo 'PASS: Correct report acknowledged; original reports are intact.'
    echo 'Your short demonstration recording is still required.'
else
    echo 'NOT YET: Create one .ok acknowledgment for the newest report.'
    echo 'HINT: Find the ls option that lists newest modification times first.'
    exit 1
fi
